# AeroTune — Android music player

A native Android music player prototype with an original Windows Vista / Windows 7 Aero-inspired interface. This is an independent project, not a Microsoft product, Windows port, Samsung app, Spotify client, or YouTube Music client.

## What's implemented

- **Local music library:** scans Android's indexed music collection and supports importing multiple audio files through the system document picker.
- **Playback engine:** AndroidX Media3 ExoPlayer with background playback, audio focus handling, headset-disconnect handling, media metadata, and system transport controls.
- **Album art:** reads Android MediaStore album artwork and displays cover thumbnails in the player and library rows.
- **Sound modes:** Normal, Nightcore (faster + brighter pitch), Slowed (lower speed + pitch), and Dynamic Bass (Android BassBoost effect when the output/device supports it).
- **Aero themes:** Vista Aero and Windows 7-inspired palettes, each with independent light and dark appearance.
- **Touch feedback:** optional short haptic tick, low-volume original bubble sound, and a circular water-shimmer animation on Aero buttons.
- **External music hand-off:** opens Spotify and YouTube Music searches. With Notification Access granted, it can discover active Android media sessions and control play/pause/next for Spotify, YouTube Music, Samsung Music and other compatible players.
- **Samsung Now Bar foundation:** exposes a normal Media3 `MediaSessionService`. On supported Samsung devices, this is the public Android integration path used for lock-screen/system media controls.

## Build the APK

The source project was created in an environment without the Android SDK or Gradle installed, so an APK could not be compiled or device-tested here. Build it on a machine with Android Studio / Android SDK installed:

1. Install **Android Studio**, **JDK 17**, and **Android SDK Platform 35**. Use **Gradle 8.13** for the configured Android Gradle Plugin 8.13.2.
2. Open this `AeroTune` folder in Android Studio and allow Gradle sync to complete. The Gradle build uses Android Gradle Plugin 8.13.2, Gradle 8.13, Kotlin 2.2.0 and AndroidX Media3 1.11.1.
3. Run **Build → Build Bundle(s) / APK(s) → Build APK(s)**, or run `gradle :app:assembleDebug` from the project root.
4. The debug APK is created at `app/build/outputs/apk/debug/app-debug.apk`.

A GitHub Actions workflow is included at `.github/workflows/android.yml`. Push this project to a GitHub repository and run the workflow (or push to `main` / `master`) to build the debug APK as a downloadable workflow artifact.

## Install and first-run setup

1. Install the debug APK on an Android phone (minimum Android 8.0 / API 26).
2. Grant **Music and audio** permission so the local library can be scanned, or use **Add files** to import tracks individually.
3. Start a song. Android's media notification and media session are provided by Media3.
4. On Samsung phones that support Now Bar, enable **Settings → Lock screen and AOD → Now bar → Media player**. Samsung documents Now Bar availability for eligible Android 15 / One UI 7+ devices and requires a screen lock. Menu names may vary by device/region.
5. To control Spotify / YouTube Music from the Connect tab, grant AeroTune **Notification Access**, start a track in the chosen app, then return to AeroTune and tap **Refresh**.

## Audio and service limitations

- No player can promise literally every audio file. Media3 supports common formats such as MP3, AAC/M4A, WAV, Ogg (Vorbis/Opus), FLAC, WebM and Matroska when the contained codec is supported by the Android device. Less common codecs may need an additional FFmpeg decoder build or may not play on a particular handset.
- Nightcore and Slowed use playback speed/pitch parameters; this is speed/pitch shifting, not a studio-grade time-stretch algorithm.
- Bass enhancement uses Android's `BassBoost` audio effect. Availability and the audible result depend on the device, output route, and vendor audio stack.
- Spotify's official Android App Remote SDK controls the Spotify app and reads its playback state; it does not let an independent player re-stream Spotify catalogue audio. This prototype uses Android's public media-session bridge for active external playback instead of embedding Spotify streaming.
- YouTube Music does not provide an official public Android SDK for a third-party app to stream its catalogue as a replacement client. AeroTune opens YouTube Music searches and uses Android media-session controls for an active session when available. It does not extract streams or bypass ads/subscriptions.
- Now Bar display is controlled by Samsung System UI and user settings. AeroTune publishes the standard Android media session; Samsung decides whether/how it appears on a particular model and One UI version.
- The bar visualizer in this first build is an animated visual accent, not a measured audio spectrum analyzer.

## UI / asset approach

The buttons, panels, icon treatment and gradients are drawn in the app as original Aero-inspired UI. The project does **not** bundle extracted Windows icons, cursors, wallpapers, system sounds, proprietary logos, or VistaReimagined assets. The provided `windows-ui-assets` repository notes that its extracted Microsoft graphics and audio retain Microsoft's original licensing terms and are for archival / educational / personal use; they are not MIT-licensed just because the repository's Markdown is MIT-licensed. If you own or have permission to use specific assets, place them in `app/src/main/res/drawable` or `app/src/main/res/raw` and wire them into the UI.

## Project layout

```text
AeroTune/
  app/src/main/AndroidManifest.xml
  app/src/main/java/com/aerotune/player/MainActivity.kt
  app/src/main/java/com/aerotune/player/audio/PlaybackService.kt
  app/src/main/java/com/aerotune/player/audio/ExternalSessionListener.kt
  app/src/main/java/com/aerotune/player/ui/AeroGlassButton.kt
  app/src/main/java/com/aerotune/player/ui/AeroFeedback.kt
  app/src/main/res/raw/aero_bubble.wav
  .github/workflows/android.yml
```

## App identity

- App label: **AeroTune**
- Package: `com.aerotune.player`
- Version: `1.0.0` (prototype)
- Minimum Android: 8.0 (API 26)
- Compile / target SDK: 35
