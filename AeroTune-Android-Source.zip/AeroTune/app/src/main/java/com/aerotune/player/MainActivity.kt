package com.aerotune.player

import android.Manifest
import android.app.NotificationManager
import android.content.ComponentName
import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.session.MediaController as SystemMediaController
import android.media.session.MediaSessionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.provider.Settings
import android.provider.OpenableColumns
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.aerotune.player.audio.ExternalSessionListener
import com.aerotune.player.audio.PlaybackService
import com.aerotune.player.ui.AeroFeedback
import com.aerotune.player.ui.AeroGlassButton
import java.util.Locale

private data class AudioTrackItem(
    val id: Long,
    val uri: Uri,
    val title: String,
    val artist: String,
    val album: String,
    val duration: Long,
    val artwork: Uri? = null
)

private enum class PlayerMode(val label: String, val speed: Float, val pitch: Float) {
    NORMAL("Normal", 1.00f, 1.00f),
    NIGHTCORE("Nightcore", 1.20f, 1.16f),
    SLOWED("Slowed", 0.82f, 0.82f),
    DYNAMIC_BASS("Dynamic bass", 1.00f, 1.00f)
}

class MainActivity : AppCompatActivity() {
    private enum class Section { NOW_PLAYING, LIBRARY, TWEAKS, CONNECTIONS }

    private val prefs by lazy { getSharedPreferences("aerotune", MODE_PRIVATE) }
    private var visualTheme = "vista" // vista | seven
    private var darkMode = false
    private var mode = PlayerMode.NORMAL
    private var library = mutableListOf<AudioTrackItem>()
    private var filteredLibrary = mutableListOf<AudioTrackItem>()
    private var section = Section.NOW_PLAYING
    private var controller: MediaController? = null
    private var controllerFuture: com.google.common.util.concurrent.ListenableFuture<MediaController>? = null
    private var remoteController: SystemMediaController? = null

    private lateinit var page: LinearLayout
    private lateinit var content: LinearLayout
    private var artworkView: ImageView? = null
    private var songTitleView: TextView? = null
    private var artistView: TextView? = null
    private var positionView: TextView? = null
    private var durationView: TextView? = null
    private var progressView: SeekBar? = null
    private var playButton: AeroGlassButton? = null
    private var queryInput: EditText? = null
    private var bassValue: TextView? = null

    private val mainHandler = Handler(Looper.getMainLooper())
    private val progressLoop = object : Runnable {
        override fun run() {
            updatePlaybackProgress()
            mainHandler.postDelayed(this, 500)
        }
    }

    private val audioPermissionLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) scanDeviceAudio() else toast("Audio permission is needed to scan your music. You can still add files manually.")
    }
    private val notificationPermissionLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }
    private val openAudioFiles = registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNullOrEmpty()) return@registerForActivityResult
        val added = uris.mapNotNull { uri ->
            try {
                contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (_: Exception) { }
            trackFromUri(uri)
        }
        library.addAll(added)
        filteredLibrary = library.toMutableList()
        toast("Added ${added.size} audio file(s)")
        showSection(Section.LIBRARY)
    }

    private val playerListener = object : Player.Listener {
        override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
            refreshCurrentTrack()
        }
        override fun onIsPlayingChanged(isPlaying: Boolean) {
            updatePlayButton()
        }
        override fun onPlaybackStateChanged(playbackState: Int) {
            refreshCurrentTrack()
        }
        override fun onRepeatModeChanged(repeatMode: Int) {
            // Button state is updated on the next screen render.
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        visualTheme = prefs.getString("theme", "vista") ?: "vista"
        darkMode = prefs.getBoolean("dark", false)
        mode = PlayerMode.values().firstOrNull { it.name == prefs.getString("mode", "NORMAL") } ?: PlayerMode.NORMAL
        AeroFeedback.init(this)
        buildShell()
        connectPlaybackService()
        askForNotifications()
        if (hasAudioPermission()) scanDeviceAudio()
    }

    private fun buildShell() {
        window.statusBarColor = if (darkMode) 0xFF071827.toInt() else 0xFFB8DFF2.toInt()
        window.navigationBarColor = if (darkMode) 0xFF071827.toInt() else 0xFFC9E7F4.toInt()
        window.decorView.systemUiVisibility = if (darkMode) 0 else
            (View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR)
        val scroll = ScrollView(this).apply {
            isFillViewport = true
            clipToPadding = false
            setPadding(dp(12), dp(8), dp(12), dp(24))
            background = backdrop()
        }
        page = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(page, ScrollView.LayoutParams(-1, -2))
        setContentView(scroll)

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(5), dp(9), dp(5), dp(13))
        }
        val orb = TextView(this).apply {
            text = "◉"
            textSize = 28f
            setTextColor(if (darkMode) Color.rgb(142, 221, 255) else Color.rgb(13, 117, 184))
            gravity = Gravity.CENTER
        }
        header.addView(orb, LinearLayout.LayoutParams(dp(42), dp(42)))
        val brand = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        brand.addView(label("AeroTune", 22f, bold = true, color = ink()))
        brand.addView(label("DIGITAL MEDIA PLAYER", 9f, bold = true, color = muted()))
        header.addView(brand, LinearLayout.LayoutParams(0, -2, 1f))
        val themeButton = button(if (darkMode) "☼" else "◐", "Theme", small = true)
        themeButton.setOnClickListener { cycleTheme() }
        header.addView(themeButton, LinearLayout.LayoutParams(dp(52), dp(42)))
        page.addView(header)

        val nav = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(dp(5), dp(5), dp(5), dp(5))
            background = panelBackground()
        }
        addNav(nav, "NOW PLAYING", Section.NOW_PLAYING)
        addNav(nav, "LIBRARY", Section.LIBRARY)
        addNav(nav, "TWEAKS", Section.TWEAKS)
        addNav(nav, "CONNECT", Section.CONNECTIONS)
        page.addView(nav, LinearLayout.LayoutParams(-1, dp(48)).apply { bottomMargin = dp(12) })

        content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        page.addView(content, LinearLayout.LayoutParams(-1, -2))
        showSection(section)
    }

    private fun addNav(nav: LinearLayout, text: String, target: Section) {
        val tab = AeroGlassButton(this).apply {
            this.text = text
            textSize = 9.5f
            accent = if (target == section) accent() else muted()
            dark = darkMode
            setPadding(dp(3), dp(4), dp(3), dp(4))
            alpha = if (target == section) 1f else 0.78f
            setOnClickListener { showSection(target) }
        }
        nav.addView(tab, LinearLayout.LayoutParams(0, dp(38), 1f).apply { marginEnd = dp(3) })
    }

    private fun showSection(target: Section) {
        section = target
        artworkView = null
        songTitleView = null
        artistView = null
        positionView = null
        durationView = null
        progressView = null
        playButton = null
        content.removeAllViews()
        when (target) {
            Section.NOW_PLAYING -> buildNowPlaying()
            Section.LIBRARY -> buildLibrary()
            Section.TWEAKS -> buildTweaks()
            Section.CONNECTIONS -> buildConnections()
        }
        // Refresh the selected tab's pressed/active tint.
        if (::page.isInitialized) {
            val nav = page.getChildAt(1) as? LinearLayout
            nav?.let {
                for (i in 0 until it.childCount) {
                    val tab = it.getChildAt(i) as AeroGlassButton
                    val selected = listOf(Section.NOW_PLAYING, Section.LIBRARY, Section.TWEAKS, Section.CONNECTIONS)[i] == target
                    tab.alpha = if (selected) 1f else 0.78f
                    tab.accent = if (selected) accent() else muted()
                }
            }
        }
    }

    private fun buildNowPlaying() {
        content.addView(label("NOW PLAYING", 11f, bold = true, color = muted()), margin(4, 0, 0, 8))
        val playerPanel = panel().apply { gravity = Gravity.CENTER_HORIZONTAL }
        val topLine = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        topLine.addView(label("AERO • LIVE SESSION", 9f, bold = true, color = muted()), LinearLayout.LayoutParams(0, -2, 1f))
        topLine.addView(label("● READY", 9f, bold = true, color = accent()))
        playerPanel.addView(topLine, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })

        val artFrame = LinearLayout(this).apply {
            gravity = Gravity.CENTER
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR,
                intArrayOf(if (darkMode) 0xFF173D58.toInt() else 0xFFB5DDF1.toInt(),
                    if (darkMode) 0xFF071B2A.toInt() else 0xFFEAF8FD.toInt())).apply { cornerRadius = dp(22).toFloat() }
            setPadding(dp(9), dp(9), dp(9), dp(9))
        }
        val art = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            background = GradientDrawable().apply { cornerRadius = dp(16).toFloat(); setColor(if (darkMode) 0xFF16364A.toInt() else 0xFFD7EFFB.toInt()) }
            clipToOutline = true
            setImageResource(R.drawable.ic_aerotune)
        }
        artworkView = art
        artFrame.addView(art, LinearLayout.LayoutParams(dp(218), dp(218)))
        playerPanel.addView(artFrame, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(13) })

        songTitleView = label("Choose a song", 20f, bold = true, color = ink()).apply { gravity = Gravity.CENTER }
        artistView = label("Your music library is waiting", 13f, color = muted()).apply { gravity = Gravity.CENTER }
        playerPanel.addView(songTitleView)
        playerPanel.addView(artistView, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(3); bottomMargin = dp(12) })

        val visualizer = VisualizerStrip(this, darkMode, accent())
        playerPanel.addView(visualizer, LinearLayout.LayoutParams(-1, dp(36)).apply { bottomMargin = dp(7) })

        val seek = SeekBar(this).apply {
            max = 1000
            progressTintList = android.content.res.ColorStateList.valueOf(accent())
            thumbTintList = android.content.res.ColorStateList.valueOf(if (darkMode) Color.WHITE else accent())
            progressBackgroundTintList = android.content.res.ColorStateList.valueOf(if (darkMode) 0xFF355468.toInt() else 0xFFBDD6E4.toInt())
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, value: Int, fromUser: Boolean) {
                    if (fromUser) positionView?.text = timeText((controller?.duration?.coerceAtLeast(0L) ?: 0L) * value / 1000)
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) { }
                override fun onStopTrackingTouch(seekBar: SeekBar?) {
                    val duration = controller?.duration ?: 0L
                    if (duration > 0) controller?.seekTo(duration * (seekBar?.progress ?: 0) / 1000)
                }
            })
        }
        progressView = seek
        playerPanel.addView(seek, LinearLayout.LayoutParams(-1, dp(30)))
        val timings = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val elapsedLabel = label("0:00", 10f, color = muted())
        val totalLabel = label("0:00", 10f, color = muted()).apply { gravity = Gravity.RIGHT }
        positionView = elapsedLabel
        durationView = totalLabel
        timings.addView(elapsedLabel, LinearLayout.LayoutParams(0, -2, 1f))
        timings.addView(totalLabel)
        playerPanel.addView(timings, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12) })

        val controls = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        val shuffle = button("⤨", "Shuffle", small = true)
        shuffle.setOnClickListener {
            controller?.shuffleModeEnabled = !(controller?.shuffleModeEnabled ?: false)
            toast(if (controller?.shuffleModeEnabled == true) "Shuffle on" else "Shuffle off")
        }
        val previous = button("|◀", "Previous", small = true)
        previous.setOnClickListener { controller?.seekToPreviousMediaItem() }
        playButton = button("▶", "Play", orb = true).apply { textSize = 20f }
        playButton?.setOnClickListener { togglePlayback() }
        val next = button("▶|", "Next", small = true)
        next.setOnClickListener { controller?.seekToNextMediaItem() }
        val repeat = button("↻", "Repeat", small = true)
        repeat.setOnClickListener {
            val current = controller?.repeatMode ?: Player.REPEAT_MODE_OFF
            controller?.repeatMode = if (current == Player.REPEAT_MODE_ALL) Player.REPEAT_MODE_ONE else Player.REPEAT_MODE_ALL
            toast(if (controller?.repeatMode == Player.REPEAT_MODE_ONE) "Repeat one" else "Repeat all")
        }
        controls.addView(shuffle, LinearLayout.LayoutParams(0, dp(45), 1f).apply { marginEnd = dp(5) })
        controls.addView(previous, LinearLayout.LayoutParams(0, dp(45), 1f).apply { marginEnd = dp(5) })
        controls.addView(playButton, LinearLayout.LayoutParams(0, dp(56), 1.25f).apply { marginEnd = dp(5) })
        controls.addView(next, LinearLayout.LayoutParams(0, dp(45), 1f).apply { marginEnd = dp(5) })
        controls.addView(repeat, LinearLayout.LayoutParams(0, dp(45), 1f))
        playerPanel.addView(controls)
        content.addView(playerPanel)

        val modesPanel = panel()
        modesPanel.addView(label("QUICK SOUND MODES", 11f, bold = true, color = muted()), margin(0, 0, 0, 9))
        val modeRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        PlayerMode.values().forEach { soundMode ->
            val modeButton = button(soundMode.label, soundMode.label, small = true).apply {
                textSize = 10f
                accent = if (soundMode == mode) accent() else muted()
                alpha = if (soundMode == mode) 1f else 0.83f
                setOnClickListener { setMode(soundMode); showSection(Section.NOW_PLAYING) }
            }
            modeRow.addView(modeButton, LinearLayout.LayoutParams(0, dp(39), 1f).apply { marginEnd = dp(4) })
        }
        modesPanel.addView(modeRow)
        content.addView(modesPanel, margin(0, 10, 0, 0))

        val libraryActions = panel()
        libraryActions.addView(label("YOUR COLLECTION", 11f, bold = true, color = muted()), margin(0, 0, 0, 8))
        val actionRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val browse = button("▤  Browse library", "Browse")
        browse.setOnClickListener { showSection(Section.LIBRARY) }
        val add = button("＋  Add files", "Add")
        add.setOnClickListener { openAudioFiles.launch(arrayOf("audio/*")) }
        actionRow.addView(browse, LinearLayout.LayoutParams(0, dp(44), 1f).apply { marginEnd = dp(7) })
        actionRow.addView(add, LinearLayout.LayoutParams(0, dp(44), 1f))
        libraryActions.addView(actionRow)
        content.addView(libraryActions, margin(0, 10, 0, 0))
        refreshCurrentTrack()
        updatePlaybackProgress()
    }

    private fun buildLibrary() {
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        header.addView(label("MUSIC LIBRARY", 11f, bold = true, color = muted()), LinearLayout.LayoutParams(0, -2, 1f))
        val scan = button("↻ Scan", "Scan", small = true)
        scan.setOnClickListener { requestAudioAccessOrScan() }
        val add = button("＋ Add", "Add", small = true)
        add.setOnClickListener { openAudioFiles.launch(arrayOf("audio/*")) }
        header.addView(scan, LinearLayout.LayoutParams(dp(76), dp(38)).apply { marginEnd = dp(5) })
        header.addView(add, LinearLayout.LayoutParams(dp(73), dp(38)))
        content.addView(header, margin(3, 0, 3, 10))

        queryInput = EditText(this).apply {
            hint = "Search songs, artists or albums"
            textSize = 13f
            setSingleLine(true)
            setTextColor(ink())
            setHintTextColor(muted())
            setPadding(dp(14), dp(9), dp(14), dp(9))
            background = inputBackground()
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) { }
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                    val q = s?.toString()?.trim()?.lowercase(Locale.getDefault()).orEmpty()
                    filteredLibrary = library.filter {
                        it.title.lowercase().contains(q) || it.artist.lowercase().contains(q) || it.album.lowercase().contains(q)
                    }.toMutableList()
                    renderTrackRows(rowsContainer)
                }
                override fun afterTextChanged(s: Editable?) { }
            })
        }
        content.addView(queryInput, LinearLayout.LayoutParams(-1, dp(46)).apply { bottomMargin = dp(9) })

        val stats = label("${library.size} TRACKS  •  ON THIS DEVICE", 9f, bold = true, color = muted())
        content.addView(stats, margin(4, 0, 4, 9))
        val listPanel = panel()
        rowsContainer = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        listPanel.addView(rowsContainer, LinearLayout.LayoutParams(-1, -2))
        content.addView(listPanel)
        renderTrackRows(rowsContainer)
    }

    private lateinit var rowsContainer: LinearLayout

    private fun renderTrackRows(container: LinearLayout) {
        if (!::rowsContainer.isInitialized) return
        container.removeAllViews()
        if (filteredLibrary.isEmpty()) {
            val empty = label(if (library.isEmpty()) "No local tracks found yet. Scan your device or add audio files." else "No matching tracks.", 13f, color = muted())
            empty.gravity = Gravity.CENTER
            container.addView(empty, LinearLayout.LayoutParams(-1, dp(130)))
            return
        }
        filteredLibrary.take(300).forEachIndexed { index, track ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(6), dp(7), dp(6), dp(7))
                isClickable = true
                isFocusable = true
                background = rowRipple()
                setOnClickListener { playTrack(track) }
            }
            val cover = ImageView(this).apply {
                scaleType = ImageView.ScaleType.CENTER_CROP
                background = GradientDrawable().apply { cornerRadius = dp(9).toFloat(); setColor(if (darkMode) 0xFF1B4159.toInt() else 0xFFD7EEF9.toInt()) }
                clipToOutline = true
                setImageResource(R.drawable.ic_aerotune)
                track.artwork?.let { setImageURI(it) }
            }
            row.addView(cover, LinearLayout.LayoutParams(dp(48), dp(48)).apply { marginEnd = dp(10) })
            val meta = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            meta.addView(label(track.title, 14f, bold = true, color = ink(), maxLines = 1))
            meta.addView(label("${track.artist}  •  ${track.album}", 10f, color = muted(), maxLines = 1), margin(0, 3, 0, 0))
            row.addView(meta, LinearLayout.LayoutParams(0, -2, 1f))
            row.addView(label(timeText(track.duration), 10f, color = muted()))
            container.addView(row)
            if (index < filteredLibrary.size - 1) {
                val divider = View(this).apply { setBackgroundColor(if (darkMode) 0x334B7892 else 0x33FFFFFF) }
                container.addView(divider, LinearLayout.LayoutParams(-1, dp(1)))
            }
        }
    }

    private fun buildTweaks() {
        content.addView(label("SOUND LAB", 11f, bold = true, color = muted()), margin(4, 0, 0, 9))
        val modes = panel()
        modes.addView(label("PLAYBACK MODES", 12f, bold = true, color = ink()), margin(0, 0, 0, 4))
        modes.addView(label("Quick presets. Tap again to return to Normal.", 11f, color = muted()), margin(0, 0, 0, 12))
        PlayerMode.values().forEach { soundMode ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            val name = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            name.addView(label(soundMode.label, 14f, bold = true, color = ink()))
            val detail = when (soundMode) {
                PlayerMode.NORMAL -> "Original pitch and playback speed"
                PlayerMode.NIGHTCORE -> "Faster tempo with a brighter pitch"
                PlayerMode.SLOWED -> "Relaxed tempo with a lower pitch"
                PlayerMode.DYNAMIC_BASS -> "Live low-end enhancement"
            }
            name.addView(label(detail, 10f, color = muted()), margin(0, 2, 0, 0))
            row.addView(name, LinearLayout.LayoutParams(0, -2, 1f))
            val choose = button(if (mode == soundMode) "✓ ACTIVE" else "USE MODE", "Choose ${soundMode.label}", small = true)
            choose.textSize = 9f
            choose.accent = if (mode == soundMode) accent() else muted()
            choose.setOnClickListener { setMode(soundMode); showSection(Section.TWEAKS) }
            row.addView(choose, LinearLayout.LayoutParams(dp(100), dp(38)))
            modes.addView(row, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(13) })
        }
        content.addView(modes)

        val bass = panel()
        bass.addView(label("DYNAMIC BASS", 12f, bold = true, color = ink()), margin(0, 0, 0, 4))
        bass.addView(label("Hardware-supported Android bass enhancement. Some audio outputs may ignore it.", 10f, color = muted()), margin(0, 0, 0, 8))
        val strengthRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        strengthRow.addView(label("Strength", 12f, color = ink()), LinearLayout.LayoutParams(0, -2, 1f))
        bassValue = label("${prefs.getInt("bass", 650) / 10}%", 11f, bold = true, color = accent())
        strengthRow.addView(bassValue)
        bass.addView(strengthRow)
        val slider = SeekBar(this).apply {
            max = 1000
            progress = prefs.getInt("bass", 650)
            progressTintList = android.content.res.ColorStateList.valueOf(accent())
            thumbTintList = android.content.res.ColorStateList.valueOf(accent())
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, value: Int, fromUser: Boolean) {
                    bassValue?.text = "${value / 10}%"
                    prefs.edit().putInt("bass", value).apply()
                    sendBass(value)
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) { }
                override fun onStopTrackingTouch(seekBar: SeekBar?) { }
            })
        }
        bass.addView(slider)
        content.addView(bass, margin(0, 10, 0, 0))

        val volumePanel = panel()
        val volumeHeader = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        volumeHeader.addView(label("PLAYER VOLUME", 12f, bold = true, color = ink()), LinearLayout.LayoutParams(0, -2, 1f))
        val volumePercent = label("${((controller?.volume ?: 1f) * 100).toInt()}%", 11f, bold = true, color = accent())
        volumeHeader.addView(volumePercent)
        volumePanel.addView(volumeHeader)
        volumePanel.addView(SeekBar(this).apply {
            max = 100
            progress = ((controller?.volume ?: 1f) * 100).toInt().coerceIn(0, 100)
            progressTintList = android.content.res.ColorStateList.valueOf(accent())
            thumbTintList = android.content.res.ColorStateList.valueOf(accent())
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, value: Int, fromUser: Boolean) {
                    volumePercent.text = "$value%"
                    if (fromUser) controller?.volume = value / 100f
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) { }
                override fun onStopTrackingTouch(seekBar: SeekBar?) { }
            })
        })
        content.addView(volumePanel, margin(0, 10, 0, 0))

        val preferences = panel()
        preferences.addView(label("PERSONAL PREFERENCES", 12f, bold = true, color = ink()), margin(0, 0, 0, 9))
        val themeRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val vista = button("Vista Aero", "Vista theme")
        vista.setOnClickListener { visualTheme = "vista"; prefs.edit().putString("theme", visualTheme).apply(); buildShell() }
        val seven = button("Windows 7", "Windows 7 theme")
        seven.setOnClickListener { visualTheme = "seven"; prefs.edit().putString("theme", visualTheme).apply(); buildShell() }
        themeRow.addView(vista, LinearLayout.LayoutParams(0, dp(42), 1f).apply { marginEnd = dp(6) })
        themeRow.addView(seven, LinearLayout.LayoutParams(0, dp(42), 1f))
        preferences.addView(themeRow, margin(0, 0, 0, 8))
        val appearance = button(if (darkMode) "☀  Switch to light glass" else "☾  Switch to dark glass", "Toggle appearance")
        appearance.setOnClickListener { darkMode = !darkMode; prefs.edit().putBoolean("dark", darkMode).apply(); buildShell() }
        preferences.addView(appearance, LinearLayout.LayoutParams(-1, dp(42)).apply { bottomMargin = dp(10) })
        addPreferenceToggle(preferences, "Haptic feedback", "A tiny tactile tick on taps", "haptics", true)
        addPreferenceToggle(preferences, "Water bubble sound", "Soft, low-volume glassy tap sound", "ui_sounds", true)
        content.addView(preferences, margin(0, 10, 0, 0))
    }

    private fun addPreferenceToggle(parent: LinearLayout, title: String, subtitle: String, key: String, default: Boolean) {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val textCol = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        textCol.addView(label(title, 13f, bold = true, color = ink()))
        textCol.addView(label(subtitle, 10f, color = muted()), margin(0, 2, 0, 0))
        row.addView(textCol, LinearLayout.LayoutParams(0, -2, 1f))
        val toggle = android.widget.Switch(this).apply {
            isChecked = prefs.getBoolean(key, default)
            setTextColor(ink())
            setOnCheckedChangeListener { _, checked -> prefs.edit().putBoolean(key, checked).apply() }
        }
        row.addView(toggle)
        parent.addView(row, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12) })
    }

    private fun buildConnections() {
        content.addView(label("ONLINE MUSIC", 11f, bold = true, color = muted()), margin(4, 0, 0, 9))
        val info = panel()
        info.addView(label("Connect to the music apps already on your phone", 16f, bold = true, color = ink()), margin(0, 0, 0, 7))
        info.addView(label("AeroTune can open Spotify and YouTube Music searches, then read and control their active Android media sessions after you grant Notification Access. Their streams stay inside their own apps.", 11f, color = muted()), margin(0, 0, 0, 10))
        queryInput = EditText(this).apply {
            hint = "Search for an artist or song"
            textSize = 13f
            setSingleLine(true)
            setTextColor(ink())
            setHintTextColor(muted())
            setPadding(dp(13), dp(9), dp(13), dp(9))
            background = inputBackground()
        }
        info.addView(queryInput, LinearLayout.LayoutParams(-1, dp(45)).apply { bottomMargin = dp(9) })
        val apps = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val spotify = button("Spotify", "Search Spotify")
        spotify.setOnClickListener { openSpotifySearch(queryInput?.text?.toString().orEmpty()) }
        val youtube = button("YouTube Music", "Search YouTube Music")
        youtube.textSize = 11f
        youtube.setOnClickListener { openYouTubeMusicSearch(queryInput?.text?.toString().orEmpty()) }
        apps.addView(spotify, LinearLayout.LayoutParams(0, dp(43), 1f).apply { marginEnd = dp(6) })
        apps.addView(youtube, LinearLayout.LayoutParams(0, dp(43), 1f))
        info.addView(apps)
        content.addView(info)

        val remotePanel = panel()
        val remoteHeader = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        remoteHeader.addView(label("ACTIVE MEDIA SESSIONS", 12f, bold = true, color = ink()), LinearLayout.LayoutParams(0, -2, 1f))
        val refresh = button("↻ Refresh", "Refresh sessions", small = true)
        refresh.setOnClickListener { refreshExternalSessions(remotePanel) }
        remoteHeader.addView(refresh, LinearLayout.LayoutParams(dp(85), dp(37)))
        remotePanel.addView(remoteHeader, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(9) })
        content.addView(remotePanel, margin(0, 10, 0, 0))

        val access = button("Grant notification access", "Notification access")
        access.setOnClickListener { openNotificationAccess() }
        content.addView(access, LinearLayout.LayoutParams(-1, dp(43)).apply { topMargin = dp(9) })
        refreshExternalSessions(remotePanel)
    }

    private fun refreshExternalSessions(panel: LinearLayout) {
        while (panel.childCount > 1) panel.removeViewAt(1)
        if (!hasNotificationAccess()) {
            panel.addView(label("Grant Notification Access to discover currently playing Spotify, YouTube Music, Samsung Music and other media sessions.", 11f, color = muted()), margin(0, 4, 0, 0))
            return
        }
        try {
            val manager = getSystemService(Context.MEDIA_SESSION_SERVICE) as MediaSessionManager
            val sessions = manager.getActiveSessions(ComponentName(this, ExternalSessionListener::class.java))
                .filter { it.packageName != packageName }
            if (sessions.isEmpty()) {
                panel.addView(label("No external player is active. Start a track in Spotify or YouTube Music, then tap Refresh.", 11f, color = muted()), margin(0, 4, 0, 0))
                return
            }
            sessions.forEach { session ->
                val appName = when (session.packageName) {
                    "com.spotify.music" -> "Spotify"
                    "com.google.android.apps.youtube.music" -> "YouTube Music"
                    "com.sec.android.app.music" -> "Samsung Music"
                    else -> session.packageName.substringAfterLast('.')
                }
                val meta = session.metadata
                val title = meta?.getString(android.media.MediaMetadata.METADATA_KEY_TITLE) ?: "Playing audio"
                val artist = meta?.getString(android.media.MediaMetadata.METADATA_KEY_ARTIST) ?: appName
                val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
                val description = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
                description.addView(label(appName, 13f, bold = true, color = ink()))
                description.addView(label("$title — $artist", 10f, color = muted(), maxLines = 1), margin(0, 2, 0, 0))
                row.addView(description, LinearLayout.LayoutParams(0, -2, 1f))
                val playPause = button(if (session.playbackState?.state == android.media.session.PlaybackState.STATE_PLAYING) "Ⅱ" else "▶", "Play or pause $appName", small = true)
                playPause.setOnClickListener {
                    remoteController = session
                    val state = session.playbackState?.state
                    if (state == android.media.session.PlaybackState.STATE_PLAYING) session.transportControls.pause() else session.transportControls.play()
                    mainHandler.postDelayed({ refreshExternalSessions(panel) }, 400)
                }
                val next = button("▶|", "Next in $appName", small = true)
                next.setOnClickListener { session.transportControls.skipToNext() }
                row.addView(playPause, LinearLayout.LayoutParams(dp(48), dp(38)).apply { marginEnd = dp(5) })
                row.addView(next, LinearLayout.LayoutParams(dp(48), dp(38)))
                panel.addView(row, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })
            }
        } catch (error: SecurityException) {
            panel.addView(label("Android has not granted access yet. Open Notification Access and enable AeroTune.", 11f, color = muted()))
        } catch (_: Exception) {
            panel.addView(label("Could not read active media sessions on this device.", 11f, color = muted()))
        }
    }

    private fun openNotificationAccess() {
        try { startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }
        catch (_: Exception) { toast("Open Android Settings and search for Notification access") }
    }

    private fun hasNotificationAccess(): Boolean {
        val enabled = Settings.Secure.getString(contentResolver, "enabled_notification_listeners") ?: return false
        return enabled.contains(packageName)
    }

    private fun openSpotifySearch(query: String) {
        val uri = if (query.isBlank()) Uri.parse("spotify:") else Uri.parse("spotify:search:${Uri.encode(query)}")
        try {
            startActivity(Intent(Intent.ACTION_VIEW, uri).apply { setPackage("com.spotify.music") })
        } catch (_: Exception) {
            try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://open.spotify.com/search/${Uri.encode(query)}"))) }
            catch (_: Exception) { toast("Spotify is not installed") }
        }
    }

    private fun openYouTubeMusicSearch(query: String) {
        val url = if (query.isBlank()) "https://music.youtube.com" else "https://music.youtube.com/search?q=${Uri.encode(query)}"
        try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }
        catch (_: Exception) { toast("Could not open YouTube Music") }
    }

    private fun connectPlaybackService() {
        val token = SessionToken(this, ComponentName(this, PlaybackService::class.java))
        controllerFuture = MediaController.Builder(this, token).buildAsync()
        controllerFuture?.addListener({
            try {
                controller = controllerFuture?.get()
                controller?.addListener(playerListener)
                controller?.setPlaybackParameters(PlaybackParameters(mode.speed, mode.pitch))
                sendBass(if (mode == PlayerMode.DYNAMIC_BASS) prefs.getInt("bass", 650) else 0)
                if (controller?.mediaItemCount == 0 && library.isNotEmpty()) prepareQueue(0, autoplay = false)
                refreshCurrentTrack()
            } catch (_: Exception) {
                toast("The audio service could not start. Try reopening AeroTune.")
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun prepareQueue(index: Int, autoplay: Boolean) {
        val c = controller ?: return
        if (library.isEmpty()) return
        val items = library.map { track ->
            val metadata = MediaMetadata.Builder()
                .setTitle(track.title)
                .setArtist(track.artist)
                .setAlbumTitle(track.album)
                .apply { track.artwork?.let { setArtworkUri(it) } }
                .build()
            MediaItem.Builder().setMediaId(track.id.toString()).setUri(track.uri).setMediaMetadata(metadata).build()
        }
        c.setMediaItems(items, index.coerceIn(0, items.lastIndex), 0L)
        c.prepare()
        if (autoplay) c.play()
    }

    private fun playTrack(track: AudioTrackItem) {
        val index = library.indexOfFirst { it.uri == track.uri }
        if (index < 0) {
            library.add(track)
            prepareQueue(library.lastIndex, true)
        } else {
            prepareQueue(index, true)
        }
        showSection(Section.NOW_PLAYING)
    }

    private fun togglePlayback() {
        val c = controller ?: return
        when {
            c.mediaItemCount == 0 && library.isNotEmpty() -> prepareQueue(0, true)
            c.isPlaying -> c.pause()
            else -> c.play()
        }
        updatePlayButton()
    }

    private fun updatePlayButton() {
        playButton?.text = if (controller?.isPlaying == true) "Ⅱ" else "▶"
    }

    private fun refreshCurrentTrack() {
        val c = controller ?: return
        val current = c.currentMediaItem
        if (current == null) {
            songTitleView?.text = "Choose a song"
            artistView?.text = "Your music library is waiting"
            artworkView?.setImageResource(R.drawable.ic_aerotune)
            updatePlayButton()
            return
        }
        val title = current.mediaMetadata.title?.toString() ?: "Unknown title"
        val artist = current.mediaMetadata.artist?.toString() ?: "Unknown artist"
        songTitleView?.text = title
        artistView?.text = artist
        val uri = current.mediaMetadata.artworkUri
        if (uri != null) artworkView?.setImageURI(uri) else artworkView?.setImageResource(R.drawable.ic_aerotune)
        durationView?.text = timeText(c.duration.coerceAtLeast(0L))
        updatePlayButton()
    }

    private fun updatePlaybackProgress() {
        val c = controller ?: return
        val duration = c.duration.takeIf { it > 0L } ?: 0L
        val position = c.currentPosition.coerceAtLeast(0L)
        positionView?.text = timeText(position)
        durationView?.text = timeText(duration)
        if (duration > 0 && progressView?.isPressed != true) {
            progressView?.progress = (position * 1000 / duration).toInt().coerceIn(0, 1000)
        }
        updatePlayButton()
    }

    private fun setMode(newMode: PlayerMode) {
        mode = newMode
        prefs.edit().putString("mode", newMode.name).apply()
        controller?.setPlaybackParameters(PlaybackParameters(newMode.speed, newMode.pitch))
        val strength = if (newMode == PlayerMode.DYNAMIC_BASS) prefs.getInt("bass", 650).coerceAtLeast(200) else 0
        sendBass(strength)
        toast("${newMode.label} mode")
    }

    private fun sendBass(strength: Int) {
        try {
            startService(Intent(this, PlaybackService::class.java).apply {
                action = PlaybackService.ACTION_SET_BASS
                putExtra(PlaybackService.EXTRA_BASS, strength)
            })
        } catch (_: Exception) { }
    }

    private fun hasAudioPermission(): Boolean {
        val permission = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE
        return ContextCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED
    }

    private fun requestAudioAccessOrScan() {
        if (hasAudioPermission()) scanDeviceAudio() else {
            val permission = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE
            audioPermissionLauncher.launch(permission)
        }
    }

    private fun scanDeviceAudio() {
        if (!hasAudioPermission()) return
        val newTracks = mutableListOf<AudioTrackItem>()
        val collection = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val projection = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.ALBUM,
            MediaStore.Audio.Media.ALBUM_ID,
            MediaStore.Audio.Media.DURATION
        )
        try {
            contentResolver.query(collection, projection, "${MediaStore.Audio.Media.IS_MUSIC} != 0", null,
                "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE ASC")?.use { cursor ->
                val idCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
                val titleCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
                val artistCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
                val albumCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
                val albumIdCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM_ID)
                val durationCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
                while (cursor.moveToNext()) {
                    val id = cursor.getLong(idCol)
                    val uri = ContentUris.withAppendedId(collection, id)
                    val albumId = cursor.getLong(albumIdCol)
                    val artwork = if (albumId > 0) Uri.parse("content://media/external/audio/albumart/$albumId") else null
                    newTracks.add(AudioTrackItem(id, uri,
                        cursor.getString(titleCol) ?: "Unknown title",
                        cursor.getString(artistCol)?.takeUnless { it == "<unknown>" } ?: "Unknown artist",
                        cursor.getString(albumCol) ?: "Unknown album",
                        cursor.getLong(durationCol), artwork))
                }
            }
        } catch (_: SecurityException) {
            toast("Android blocked access to the audio library")
        } catch (_: Exception) {
            toast("Could not scan the music library")
        }
        val manuallyAdded = library.filter { it.id < 0 }
        library = (newTracks + manuallyAdded).distinctBy { it.uri }.toMutableList()
        filteredLibrary = library.toMutableList()
        if (section == Section.LIBRARY) showSection(Section.LIBRARY)
        else refreshCurrentTrack()
    }

    private fun trackFromUri(uri: Uri): AudioTrackItem? {
        return try {
            var name = "Audio file"
            contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) name = c.getString(0) ?: name
            }
            val title = name.substringBeforeLast('.', name)
            AudioTrackItem(-System.nanoTime(), uri, title, "Local file", "Imported", 0L)
        } catch (_: Exception) { null }
    }

    private fun askForNotifications() {
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    private fun cycleTheme() {
        if (visualTheme == "vista" && !darkMode) { visualTheme = "vista"; darkMode = true }
        else if (visualTheme == "vista" && darkMode) { visualTheme = "seven"; darkMode = false }
        else if (visualTheme == "seven" && !darkMode) { visualTheme = "seven"; darkMode = true }
        else { visualTheme = "vista"; darkMode = false }
        prefs.edit().putString("theme", visualTheme).putBoolean("dark", darkMode).apply()
        buildShell()
    }

    private fun buildShellAgain() = buildShell()

    private fun panel(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(14), dp(13), dp(14), dp(13))
        background = panelBackground()
        elevation = dp(2).toFloat()
    }

    private fun panelBackground(): GradientDrawable {
        val colors = when {
            darkMode && visualTheme == "vista" -> intArrayOf(0xE51A3D55.toInt(), 0xE50B2134.toInt())
            darkMode -> intArrayOf(0xE5223448.toInt(), 0xE5112336.toInt())
            visualTheme == "vista" -> intArrayOf(0xEAF8FDFF.toInt(), 0xD5DDF1F8.toInt())
            else -> intArrayOf(0xF2FFFFFF.toInt(), 0xD7E6F4FA.toInt())
        }
        return GradientDrawable(GradientDrawable.Orientation.TL_BR, colors).apply {
            cornerRadius = dp(19).toFloat()
            setStroke(dp(1), if (darkMode) 0x887DCAE9.toInt() else 0xB8FFFFFF.toInt())
        }
    }

    private fun backdrop(): GradientDrawable {
        val colors = when {
            darkMode && visualTheme == "vista" -> intArrayOf(0xFF071827.toInt(), 0xFF0D3950.toInt(), 0xFF102338.toInt())
            darkMode -> intArrayOf(0xFF091623.toInt(), 0xFF1D3650.toInt(), 0xFF102436.toInt())
            visualTheme == "vista" -> intArrayOf(0xFFB8DFF2.toInt(), 0xFFE5F6FC.toInt(), 0xFF9BD4C7.toInt())
            else -> intArrayOf(0xFFB9DDF0.toInt(), 0xFFEFF8FC.toInt(), 0xFFC2E1D7.toInt())
        }
        return GradientDrawable(GradientDrawable.Orientation.TL_BR, colors)
    }

    private fun inputBackground() = GradientDrawable().apply {
        cornerRadius = dp(13).toFloat()
        setColor(if (darkMode) 0x9922374B.toInt() else 0xBFFFFFFF.toInt())
        setStroke(dp(1), if (darkMode) 0x8879B6D4.toInt() else 0xAAFFFFFF.toInt())
    }

    private fun rowRipple(): android.graphics.drawable.Drawable {
        val mask = GradientDrawable().apply { cornerRadius = dp(10).toFloat(); setColor(Color.WHITE) }
        return android.graphics.drawable.RippleDrawable(
            android.content.res.ColorStateList.valueOf(if (darkMode) 0x667CCDF3 else 0x553F9DCC),
            null, mask)
    }

    private fun button(text: String, description: String, small: Boolean = false, orb: Boolean = false): AeroGlassButton {
        return AeroGlassButton(this).apply {
            this.text = text
            contentDescription = description
            dark = darkMode
            accent = accent()
            this.orb = orb
            textSize = if (small) 12f else 13f
            setTextColor(ink())
        }
    }

    private fun label(text: String, size: Float, bold: Boolean = false, color: Int = ink(), maxLines: Int = Int.MAX_VALUE): TextView {
        return TextView(this).apply {
            this.text = text
            textSize = size
            setTextColor(color)
            this.maxLines = maxLines
            ellipsize = android.text.TextUtils.TruncateAt.END
            typeface = Typeface.create(if (bold) "sans-serif-semibold" else "sans-serif", if (bold) Typeface.BOLD else Typeface.NORMAL)
            includeFontPadding = true
        }
    }

    private fun margin(left: Int, top: Int, right: Int, bottom: Int): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(-1, -2).apply {
            leftMargin = dp(left); topMargin = dp(top); rightMargin = dp(right); bottomMargin = dp(bottom)
        }

    private fun accent(): Int = if (visualTheme == "vista") {
        if (darkMode) 0xFF6EC8F0.toInt() else 0xFF087DB8.toInt()
    } else {
        if (darkMode) 0xFF79C8F5.toInt() else 0xFF1679B6.toInt()
    }

    private fun ink(): Int = if (darkMode) 0xFFEAF7FF.toInt() else 0xFF193B52.toInt()
    private fun muted(): Int = if (darkMode) 0xFF9DBDCE.toInt() else 0xFF55788E.toInt()
    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun timeText(milliseconds: Long): String {
        val seconds = (milliseconds.coerceAtLeast(0L) / 1000)
        return String.format(Locale.getDefault(), "%d:%02d", seconds / 60, seconds % 60)
    }

    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_SHORT).show()

    override fun onResume() {
        super.onResume()
        mainHandler.removeCallbacks(progressLoop)
        mainHandler.post(progressLoop)
        if (section == Section.CONNECTIONS && ::content.isInitialized) showSection(Section.CONNECTIONS)
    }

    override fun onPause() {
        mainHandler.removeCallbacks(progressLoop)
        super.onPause()
    }

    override fun onDestroy() {
        mainHandler.removeCallbacks(progressLoop)
        controller?.removeListener(playerListener)
        controllerFuture?.let { MediaController.releaseFuture(it) }
        controller = null
        AeroFeedback.release()
        super.onDestroy()
    }
}

/** Lightweight WMP-era equalizer bars, animated as a quiet idle visualizer. */
private class VisualizerStrip(context: Context, private val dark: Boolean, private val tint: Int) : View(context) {
    private val paint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG)
    private val values = floatArrayOf(.28f,.44f,.65f,.4f,.82f,.54f,.72f,.36f,.62f,.48f,.76f,.33f,.58f,.42f,.7f,.29f,.52f,.68f,.38f,.6f)
    private val handler = Handler(Looper.getMainLooper())
    private var phase = 0f
    private val animate = object : Runnable {
        override fun run() { phase += .37f; invalidate(); handler.postDelayed(this, 120) }
    }
    init { handler.post(animate) }
    override fun onDraw(canvas: android.graphics.Canvas) {
        super.onDraw(canvas)
        val gap = width / (values.size * 2f)
        val barWidth = gap * .82f
        val base = height * .86f
        values.forEachIndexed { index, value ->
            val heightFactor = (.2f + .72f * kotlin.math.abs(kotlin.math.sin(phase + index * .47f))).coerceIn(.15f, 1f)
            val h = height * value * heightFactor
            val left = gap * (index * 2 + .55f)
            paint.shader = android.graphics.LinearGradient(0f, base-h, 0f, base,
                if (dark) 0xFF9CEBFC.toInt() else tint, if (dark) 0xFF287CA8.toInt() else 0xFF74B7D9.toInt(), android.graphics.Shader.TileMode.CLAMP)
            canvas.drawRoundRect(left, base - h, left + barWidth, base, barWidth/2, barWidth/2, paint)
        }
        paint.shader = null
    }
    override fun onDetachedFromWindow() { handler.removeCallbacks(animate); super.onDetachedFromWindow() }
}
