package com.aerotune.player.audio

import android.content.Intent
import android.media.audiofx.BassBoost
import android.util.Log
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService

/**
 * One real MediaSession for local playback. Samsung's Now Bar and Android's
 * system media controls discover this session through the public Media3 API.
 */
@OptIn(UnstableApi::class)
class PlaybackService : MediaSessionService() {
    private var player: ExoPlayer? = null
    private var mediaSession: MediaSession? = null
    private var bassBoost: BassBoost? = null
    private var desiredBassStrength: Int = 0

    override fun onCreate() {
        super.onCreate()
        val audioAttributes = AudioAttributes.Builder()
            .setUsage(C.USAGE_MEDIA)
            .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
            .build()
        val exo = ExoPlayer.Builder(this)
            .setAudioAttributes(audioAttributes, true)
            .setHandleAudioBecomingNoisy(true)
            .build()
        exo.addListener(object : androidx.media3.common.Player.Listener {
            override fun onAudioSessionIdChanged(audioSessionId: Int) {
                if (desiredBassStrength > 0) applyBass(desiredBassStrength)
            }
        })
        player = exo
        mediaSession = MediaSession.Builder(this, exo).build()
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? = mediaSession

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_SET_BASS) {
            val strength = intent.getIntExtra(EXTRA_BASS, 0).coerceIn(0, 1000)
            applyBass(strength)
        }
        return super.onStartCommand(intent, flags, startId)
    }

    private fun applyBass(strength: Int) {
        desiredBassStrength = strength.coerceIn(0, 1000)
        val sessionId = player?.audioSessionId ?: 0
        if (sessionId <= 0) return
        try {
            if (strength <= 0) {
                bassBoost?.release()
                bassBoost = null
                return
            }
            if (bassBoost == null) bassBoost = BassBoost(0, sessionId)
            bassBoost?.setStrength(strength.toShort())
            bassBoost?.enabled = true
        } catch (error: Exception) {
            Log.w(TAG, "Bass enhancement is unavailable on this device", error)
            try { bassBoost?.release() } catch (_: Exception) { }
            bassBoost = null
        }
    }

    override fun onDestroy() {
        try { bassBoost?.release() } catch (_: Exception) { }
        bassBoost = null
        mediaSession?.release()
        mediaSession = null
        player?.release()
        player = null
        super.onDestroy()
    }

    companion object {
        const val ACTION_SET_BASS = "com.aerotune.player.action.SET_BASS"
        const val EXTRA_BASS = "bass_strength"
        private const val TAG = "AeroTunePlayback"
    }
}
