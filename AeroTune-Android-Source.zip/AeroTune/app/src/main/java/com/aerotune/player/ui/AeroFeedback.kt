package com.aerotune.player.ui

import android.content.Context
import android.media.AudioAttributes
import android.media.SoundPool
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import com.aerotune.player.R

object AeroFeedback {
    private var pool: SoundPool? = null
    private var bubbleId: Int = 0

    fun init(context: Context) {
        if (pool != null) return
        val attrs = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build()
        pool = SoundPool.Builder().setMaxStreams(2).setAudioAttributes(attrs).build()
        bubbleId = pool?.load(context.applicationContext, R.raw.aero_bubble, 1) ?: 0
    }

    fun tap(context: Context) {
        val prefs = context.getSharedPreferences("aerotune", Context.MODE_PRIVATE)
        if (prefs.getBoolean("haptics", true)) {
            try {
                val vibrator = if (Build.VERSION.SDK_INT >= 31) {
                    (context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager).defaultVibrator
                } else {
                    @Suppress("DEPRECATION")
                    context.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
                }
                if (vibrator.hasVibrator()) {
                    vibrator.vibrate(VibrationEffect.createOneShot(18, 38))
                }
            } catch (_: Exception) { }
        }
        if (prefs.getBoolean("ui_sounds", true)) {
            try {
                init(context)
                if (bubbleId != 0) pool?.play(bubbleId, 0.28f, 0.28f, 1, 0, 1.0f)
            } catch (_: Exception) { }
        }
    }

    fun release() {
        pool?.release()
        pool = null
        bubbleId = 0
    }
}
