package com.aerotune.player.audio

import android.service.notification.NotificationListenerService

/**
 * Declares the user-grantable notification listener permission required by
 * MediaSessionManager.getActiveSessions(). It does not read or forward notifications.
 */
class ExternalSessionListener : NotificationListenerService()
