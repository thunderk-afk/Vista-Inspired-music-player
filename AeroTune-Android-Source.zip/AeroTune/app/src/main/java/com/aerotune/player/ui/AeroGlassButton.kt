package com.aerotune.player.ui

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Color
import android.view.MotionEvent
import android.view.animation.DecelerateInterpolator
import androidx.appcompat.widget.AppCompatTextView
import androidx.core.content.ContextCompat
import com.aerotune.player.R
import kotlin.math.max

/** Glossy, beveled Vista/7-inspired button with a small water-ring touch shimmer. */
class AeroGlassButton(context: Context) : AppCompatTextView(context) {
    var accent = Color.rgb(32, 142, 205)
        set(value) { field = value; invalidate() }
    var dark = false
        set(value) { field = value; invalidate() }
    var orb = false
        set(value) { field = value; invalidate() }

    private val shape = RectF()
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val edge = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = dp(1.1f) }
    private val shine = Paint(Paint.ANTI_ALIAS_FLAG)
    private val shimmer = Paint(Paint.ANTI_ALIAS_FLAG)
    private var waveX = 0f
    private var waveY = 0f
    private var wave = 1f
    private var waveAnimator: ValueAnimator? = null

    init {
        setTextColor(if (dark) Color.WHITE else Color.rgb(29, 70, 99))
        textSize = 13f
        typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL)
        gravity = android.view.Gravity.CENTER
        setPadding(dp(13), dp(8), dp(13), dp(8))
        background = null
        minHeight = dp(42)
        elevation = dp(2).toFloat()
        setLayerType(LAYER_TYPE_SOFTWARE, null)
    }

    override fun onDraw(canvas: Canvas) {
        val radius = if (orb) height / 2f else dp(13).toFloat()
        shape.set(1f, 1f, width - 1f, height - 1f)
        val top = if (dark) mix(accent, Color.WHITE, 0.30f) else mix(accent, Color.WHITE, 0.84f)
        val bottom = if (dark) mix(accent, Color.BLACK, 0.46f) else mix(accent, Color.WHITE, 0.34f)
        fill.shader = LinearGradient(0f, 0f, 0f, height.toFloat(), top, bottom, Shader.TileMode.CLAMP)
        fill.alpha = if (isPressed) 225 else 255
        canvas.drawRoundRect(shape, radius, radius, fill)
        fill.shader = null
        edge.color = if (dark) Color.argb(190, 174, 222, 245) else Color.argb(210, 255, 255, 255)
        canvas.drawRoundRect(shape, radius, radius, edge)

        val glossRect = RectF(3f, 2f, width - 3f, height * 0.48f)
        shine.shader = LinearGradient(0f, 1f, 0f, glossRect.bottom,
            intArrayOf(Color.argb(175, 255, 255, 255), Color.argb(18, 255, 255, 255)),
            null, Shader.TileMode.CLAMP)
        canvas.drawRoundRect(glossRect, radius - 2f, radius - 2f, shine)
        shine.shader = null

        if (wave < 1f) {
            val maxRadius = max(width, height).toFloat() * 0.95f
            val r = maxRadius * wave
            shimmer.shader = RadialGradient(waveX, waveY, max(1f, r),
                intArrayOf(Color.argb((80 * (1f - wave)).toInt(), 255, 255, 255), Color.argb(0, 255, 255, 255)),
                floatArrayOf(0.05f, 1f), Shader.TileMode.CLAMP)
            canvas.save()
            val clip = Path().apply { addRoundRect(shape, radius, radius, Path.Direction.CW) }
            canvas.clipPath(clip)
            canvas.drawCircle(waveX, waveY, r, shimmer)
            edge.color = Color.argb((120 * (1f - wave)).toInt(), 255, 255, 255)
            edge.strokeWidth = dp(1.2f).toFloat()
            canvas.drawCircle(waveX, waveY, r * 0.72f, edge)
            canvas.restore()
            shimmer.shader = null
        }
        super.onDraw(canvas)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (event.actionMasked == MotionEvent.ACTION_DOWN) {
            waveX = event.x
            waveY = event.y
            startShimmer()
            AeroFeedback.tap(context)
        }
        return super.onTouchEvent(event)
    }

    private fun startShimmer() {
        waveAnimator?.cancel()
        wave = 0f
        waveAnimator = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 510
            interpolator = DecelerateInterpolator()
            addUpdateListener { wave = it.animatedValue as Float; invalidate() }
            start()
        }
    }

    private fun mix(foreground: Int, background: Int, amount: Float): Int {
        val inverse = 1f - amount
        return Color.rgb(
            (Color.red(foreground) * inverse + Color.red(background) * amount).toInt(),
            (Color.green(foreground) * inverse + Color.green(background) * amount).toInt(),
            (Color.blue(foreground) * inverse + Color.blue(background) * amount).toInt()
        )
    }

    private fun dp(value: Float): Int = (value * resources.displayMetrics.density).toInt()
}
