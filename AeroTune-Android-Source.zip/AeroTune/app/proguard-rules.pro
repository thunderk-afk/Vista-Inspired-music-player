# Keep Media3 session service components discoverable by Android.
-keep class androidx.media3.** { *; }
