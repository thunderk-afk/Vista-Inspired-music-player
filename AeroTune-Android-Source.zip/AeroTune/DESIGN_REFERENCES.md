# AeroTune — visual and interaction references

These links informed the product direction. The app uses them as inspiration rather than copying artwork or reproducing another product's UI one-for-one.

## Primary direction

- VistaReimagined listing: https://www.appbrain.com/app/vistareimagined-launcher-theme/com.vista.reimagined?story=1 — frosted panels, glassy blue finish, glossy buttons and retro icon language.
- Windows Media Player 11 library reference: https://betawiki.net/wiki/Windows_Media_Player_11 — left-side library taxonomy, album tiles, details and bottom transport controls.
- WMP11 visual reference: https://www.soundonsound.com/techniques/vista-musicians — library view and classic playback layout.
- Pinterest visual-search board: https://www.pinterest.com/search/pins/?q=Windows%20Vista%20Aero%20glass%20UI — secondary moodboard search for Aero glass, gradients, icon bevels and desktop-era control styling. This is a search link, not a claim that one particular pin was used.
- Dribbble, Windows Aero music-player concept: https://dribbble.com/shots/15455712-Music-Player-concept-based-on-Windows-Aero-OG-Glassmorphism — focused visual reference for a music player using Vista-era glass styling.

## Community concepts and feedback

- Reddit, mobile Windows Media Player concept: https://www.reddit.com/r/Windows_Redesign/comments/1dh04ji/concept_mobile_version_of_windows_media_player/ — direct mobile-WMP concept reference. Discussion praised the retro Windows feel and suggested the dark glass treatment worked particularly well, while noting that dated-looking controls can undermine the result.
- Reddit, mini Vista Media Player concept: https://www.reddit.com/r/FrutigerAero/comments/1pb716x/creating_mini_windows_vista_media_player/ — community interest in a compact Vista-style player.
- Reddit, WMP visualizer nostalgia: https://www.reddit.com/r/nostalgia/comments/bpju5d/windows_media_player_sound_visualizer_please_tell/ — shows how strongly the visualizer experience is associated with the older player.

## Video references

- Windows Media Player 11 visualizations: https://www.youtube.com/watch?v=Ys50oSvMqNs
- Former Windows Media Player visualizations: https://www.youtube.com/watch?v=ycPJX-LoG70
- Album-art handling in WMP11: https://www.youtube.com/watch?v=i0eGZfjoAFE

## Platform and integration documentation

- Android Media3 background playback / MediaSessionService: https://developer.android.com/media/media3/session/background-playback
- Media3 supported formats: https://developer.android.com/media/media3/exoplayer/supported-formats
- Samsung Now Bar settings / supported devices: https://www.samsung.com/us/support/answer/ANS10004605/
- Spotify Android App Remote SDK: https://developer.spotify.com/documentation/android
- YouTube Data API search: https://developers.google.com/youtube/data/reference/rest/v3/search

## Asset licensing note

The supplied Windows asset archive is here: https://github.com/bartekl1/windows-ui-assets. Its README says the repository structure/Markdown is MIT licensed, but extracted Windows wallpapers, icons, cursors and sounds remain subject to Microsoft's original terms and are not covered by the repository's MIT license. AeroTune therefore uses its own gradients, draw routines and control shapes unless separately licensed assets are supplied.
